# Antigravity prompt: finish the EGMT Activity dark redesign

Paste everything below the line into Antigravity.

---

## Context
This repo (EGMT Activity) is a React 18 + TypeScript + Vite + Tailwind CSS 3 PWA for maintenance operations, deployed on Cloudflare Pages with `functions/api` (KV). It is a dark-only, mobile-first app used on a shop floor, so touch targets and legibility matter.

The **foundation of a dark, minimal redesign is already applied**:
`tailwind.config.js` (the `slate` palette is remapped to neutral zinc, so every existing `slate-*` class is already neutral; `shadow-card` is now `none`), `src/index.css`, `index.html`, `public/manifest.webmanifest`, `src/App.tsx`, `src/components/Header.tsx`, and `src/components/ui/{Primitives,Modal,Toast}.tsx`.

`Primitives.tsx` also gained a new `StatusDot` component (small dot + label) to use instead of bordered badges.

**Your job: restyle the remaining views to match, without changing behaviour.**

Files to restyle:
- `src/components/DailyTasksView.tsx` (highest priority)
- `src/components/DowntimeView.tsx`
- `src/components/HistoryView.tsx`
- `src/components/RosterModal.tsx`

## Hard constraints
- **Styling only.** Do not change props, state, handlers, data fetching, text strings, or anything in `src/api`, `src/domain`, `src/shared`, `functions/`, `tests/`, or `public/`.
- No new dependencies. Tailwind utility classes only (v3.4: no `h-4.5`-style half-steps beyond what v3.4 supports).
- Keep every existing export, prop signature and accessibility attribute (`aria-*`, `role`, labels).
- Keep tap targets at least 44px high for the technician "complete" buttons and any primary mobile action.
- Keep the layout working at 360px wide; the fixed mobile bottom nav means page content needs bottom padding (already set in `App.tsx`).

## Design language
Dark, quiet, and modern. Structure comes from spacing and hairlines, not boxes.

**Palette (already in config):** canvas `#09090B`; surfaces `bg-surface` / `bg-surface-elevated` / `bg-surface-input`; text `zinc-100` for primary, `zinc-400` for secondary, `zinc-500` for tertiary; borders `border-white/[0.06]` (hairline) or `border-white/[0.08]` (inputs).

**One loud element:** the primary button is white (`bg-zinc-100 text-zinc-950`), via `<Button variant="primary">`. Remove amber from everything else *except* where amber means "due now" or "warning".

**Status colour is semantic and small:** red = overdue/error, amber = due now/warning, emerald = completed/ok, zinc = neutral/upcoming. Show it as a 6px dot plus a one-word label (`<StatusDot tone="red">Overdue</StatusDot>`) or coloured text. Never use tinted panels, coloured left borders, or icon+badge combos for status.

**Shape and depth:** one radius family (`rounded-lg` for controls, `rounded-xl` for grouped containers). No shadows. No gradients. No `border-l-[3px]` accent bars. Avoid nesting bordered boxes inside bordered boxes.

**Type:** 14px body, 12px secondary, 11px only for tiny captions. Drop uppercase tracked micro-labels except at most one small section label style. Use `font-mono tabular-nums` for times, dates and counts.

**Motion:** keep transitions to `transition` (colour/opacity) only; keep the existing `animate-*` classes.

## DailyTasksView: specific redesign
1. **Page header:** title `text-xl font-semibold tracking-tight`, the one-line description in `text-zinc-500`. Controls on the right: date stepper as a borderless group (chevron buttons use ghost styling, date input stays mono), "Today" and "Manage" as `Button variant="ghost"`, "Add Task" as `variant="primary"`.
2. **Summary:** replace the three bordered stat tiles with a single inline line under the header, e.g. `3 pending · 1 due now · 4 completed` (counts in `font-mono tabular-nums zinc-200`, labels in `zinc-500`). Only the overdue count turns red when greater than 0.
3. **Task list:** replace `renderOccurrenceCard` cards with **rows in a single column** (no grid, no card borders). Each row is separated by `border-b border-white/[0.06]` and uses a two-column layout:
   - Left column (fixed ~`w-14`): the scheduled time in `font-mono text-sm tabular-nums` (zinc-100; zinc-500 when completed).
   - Right column: title `text-[15px] font-medium` (line-through + zinc-500 when completed), optional description in `text-xs text-zinc-500`, then a status line using `StatusDot` (+ the shift as plain `text-zinc-500` text, e.g. "Shift M").
   - Under that, for pending rows: the technician buttons as `rounded-lg border border-white/[0.08] bg-white/[0.03]` chips, `min-h-[44px]`, hover turning emerald; keep the loading spinner and disabled behaviour. Drop the "Tap technician to complete" helper line or reduce it to a single `text-[11px] text-zinc-600` caption.
   - For completed rows: a single quiet line, e.g. `✓ Name · 14:32`, in `text-emerald-300/80` and mono for the time; no tinted box.
   - The "no technicians / Load Roster →" state becomes plain `text-xs text-zinc-500` with the link in `text-zinc-200 underline-offset-2 hover:underline`.
4. **Section headers (Overdue / Due Now / Upcoming / Completed):** a simple text row: `StatusDot` + title in `text-xs font-medium text-zinc-300` + count in `text-zinc-500`. Completed stays collapsible with the chevron. No uppercase tracking, no count pills.
5. **Manage modal and TaskFormModal:** keep structure, but: segmented controls use `bg-white/[0.04]` track with the active segment `bg-zinc-100 text-zinc-950`; weekday and time chips use neutral borders, with the active weekday `bg-white/[0.1] text-zinc-100 border-white/25` (not amber); the "Task Enabled" row loses its bordered box in favour of a hairline-divided row; replace the checkbox with a minimal toggle switch if it can be done without changing state logic.
6. **Error banners:** `rounded-xl bg-red-500/10 text-red-200 px-4 py-3`, no border.

## DowntimeView, HistoryView, RosterModal
Apply the same rules: rows and hairlines instead of cards, `StatusDot` instead of bordered badges, one white primary action per screen, amber only for warnings, uniform type scale, no tinted panels. Keep any progress bars, checklists and tables functional but flatten their styling (thin 2px progress bars in `bg-zinc-100` on `bg-white/[0.06]`; tables with hairline row dividers and no zebra striping or outer borders). Charts or heatmaps, if present, should use zinc for empty cells and emerald/red/amber only for data meaning.

## Global cleanup pass
- Search the four files for `amber-`, `emerald-`, `red-`, `sky-`, `indigo-`, `shadow-card`, `rounded-2xl`, `border-l-`, `uppercase`, and `text-[10px]`/`text-[11px]`. Each remaining use should be justified by the rules above.
- Replace any remaining `text-slate-*` with the `zinc` equivalent for clarity (they render identically).
- Ensure focus states are visible on every interactive element (a global `:focus-visible` outline already exists; do not remove it).

## Verify before finishing
Run and fix until all pass:
```
npx tsc --noEmit
npx vite build
npx vitest run
```
Then give me a short summary listing each file changed and any place where you deliberately deviated from this brief, and why.
